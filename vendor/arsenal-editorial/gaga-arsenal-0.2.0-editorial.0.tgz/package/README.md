# @gaga/arsenal

Deterministic application normalization, public-package compatibility resolution and bounded host-reader assembly.

First stable package release: 0.1.0. Node 22.22.2+.

`gaga.app/v1` and authoring APIs remain experimental. Package stability does not
freeze the schema or promise universal compatibility; future schema revisions may
precede a compatibility guarantee.

See the repository README and docs/APPLICATION.md for the complete fixture,
public API and tested compatibility boundary. No provider accounts or deployment.

## Unpublished editorial candidate

`0.2.0-editorial.0` adds the root `createPortableTextSemantics(definitions)`
factory. Its instance exposes only `validatePortableText`, `resolveSections` and
`plainText`; there is no renderer, provider adapter or publication authority.
This API retains the qualified finite Portable Text semantics and is experimental.
See the [precise contract](https://github.com/liquid-modernity/gaga-arsenal/blob/review/editorial-public-contract-v1/docs/EDITORIAL.md)
for bounds, errors, text-selection rules and compatibility limits.
