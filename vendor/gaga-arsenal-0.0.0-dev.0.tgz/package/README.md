# @gaga/arsenal

Deterministic application normalization, public-package compatibility resolution and bounded host-reader assembly.

Experimental foundation, version 0.0.0-dev.0; not published. Node 22.22.2+.

See the repository README and docs/APPLICATION.md for the complete fixture,
public API and tested compatibility boundary. No provider accounts or deployment.
