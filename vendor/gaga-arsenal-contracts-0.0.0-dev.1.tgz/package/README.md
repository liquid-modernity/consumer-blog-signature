# @gaga/arsenal-contracts

Strict gaga.app/v1 types, JSON Schema and decoder. No Engine dependency.

Experimental foundation, version 0.0.0-dev.1; not published. Node 22.22.2+.

See the repository README and docs/APPLICATION.md for the complete fixture,
public API and tested compatibility boundary. No provider accounts or deployment.
